package com.udacity.gamedev.Boulder;

import com.badlogic.Gdx.g2d.Spritebatch;
import com.badlogic.Gdx.gUtils.Viewport;
import com.badlogic.Gdx.Graphics.ShapeRenderer;

public class Boulder extends ApplicationAdapter
{
 
  ShapeRenderer srg;
  StretchViewport vpmt;
  Vector2 vel;
  Vector2 pos;

@Override
public void create()
{
 srg=new ShapeRenderer();
 vmpt=new StretchViewport(constants.WORLD_SIZE,constants.WORLD_SIZE);
 vel=new Vector2();
 pos=new Vector2(0,0);
 vel.x=0;
 pos.x=30.0f;
 pos.y=20.0f;
 
}
@Override
public void dispose()
{
 srg.dispose();

}
@Override
public void update(float delta)
{
 vel.y=vel.y+delta*constants.GRAVITY;//value of velocity in next frame

 pos.y=pos.y+delta*vel.y;//position of object in next frame



}
@Override
public void render()
{
 srg.begin(ShapeType.Filled);
 srg.circle(pos.x,pos.y,constants.RADIUS);
 srg.SetColor(constants.COLOR1);
 srg.end();
}
}
