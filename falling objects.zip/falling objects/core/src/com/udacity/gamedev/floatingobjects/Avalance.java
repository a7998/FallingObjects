package com.udacity.gamedev.Avalanche;

import com.udacity.gamedev.Boulder;
import com.badlogic.Gdx.g2d.Spritebatch;
import com.badlogic.Gdx.gUtils.Viewport;
import com.badlogic.Gdx.Graphics.ShapeRenderer;

public class Avalanche extends ApplicationAdapter 
{
 private static final float SPAWNS_PER_SECOND = 10;

    Array<Boulder> boulders;

@Override
public void create() {

    
        boulders = new Array<Boulder>();
    }

    public void update(float delta, Viewport viewport){
        Random random = new Random();
        if (random.nextFloat() < delta * SPAWNS_PER_SECOND){
            boulders.add(new Boulder(viewport));
        }

        for (int i = 0; i < boulders.size; i++){
            Boulder boulder = boulders.get(i);
            boulder.update(delta);
            if (boulder.isBelowScreen()){
                boulders.removeIndex(i);
            }
        }
    }
    @Override
    public void render(){
        for (Boulder boulder : boulders){
            boulder.render(renderer);
        }
    }
}
  