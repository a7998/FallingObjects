package com.udacity.gamedev.fallingobjects;

import com.badlogic.gdx.Game;

public class FallingObjectsGame extends Game {
    @Override
    public void create() {
        setScreen(new FallingObjectsScreen());

    }


}
