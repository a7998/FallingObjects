package com.udacity.gamedev.fallingobjectscreen;

import com.badlogic.Gdx.g2d.Spritebatch;
import com.badlogic.Gdx.gUtils.Viewport;
import com.badlogic.Gdx.Graphics.ShapeRenderer;

public class fallingObjectScreen extends ScreenAdapter
{
 Avalanche avc;
 ExtendViewport vpnt;
 ShapeRenderer rgmt;
 
@Override
public void show()
{
 avc=new Avalanche();
 vpnt=new ExtendViewport();
 rgmt=new ShapeRenderer();
}
@Override
public void update(int width,height)
{
 vpnt.update(width,height);
}
@Override
public void dispose()
{
 rgmt.dispose();
}
@Override
public void render(float delta)
{
 vpnt.apply();
 Gdx.gl.glClearColor(0,0,0,1);
 Gdx.gl.glClearColor(Gl20.GL_COLOR_BUFFER_BIT);
 avc.update(delta,vpnt);
 avc.render(rgmt);
 rgmt.end(); 

}
}
 
